#!/usr/bin/env python3
"""Executa os scripts SQL em SQLite temporário e salva os resultados em Markdown."""
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "sql" / "01_criar_tabelas.sql"
SEED = ROOT / "sql" / "02_dados_ficticios.sql"
QUERIES = ROOT / "sql" / "03_consultas.sql"
OUTPUT = ROOT / "resultados" / "consultas.md"


def markdown_table(headers, rows):
    def cell(value):
        return "" if value is None else str(value).replace("|", "\\|").replace("\n", " ")

    lines = ["| " + " | ".join(cell(h) for h in headers) + " |"]
    lines.append("| " + " | ".join("---" for _ in headers) + " |")
    lines.extend("| " + " | ".join(cell(v) for v in row) + " |" for row in rows)
    return "\n".join(lines)


def main():
    connection = sqlite3.connect(":memory:")
    connection.execute("PRAGMA foreign_keys = ON")
    connection.executescript(SCHEMA.read_text(encoding="utf-8"))
    connection.executescript(SEED.read_text(encoding="utf-8"))

    sql_text = QUERIES.read_text(encoding="utf-8")
    pattern = re.compile(r"(?m)^-- (Consulta \d+:[^\n]*)\n(.*?);", re.DOTALL)
    matches = pattern.findall(sql_text)
    if not matches:
        raise RuntimeError("Nenhuma consulta foi encontrada em sql/03_consultas.sql")

    sections = [
        "# Resultados das consultas",
        "",
        "Gerados automaticamente por `scripts/validar_e_gerar_resultados.py` usando SQLite em memória.",
        "Os dados são sintéticos. Execute o script novamente para reproduzir os resultados.",
    ]
    for title, sql in matches:
        cursor = connection.execute(sql.strip())
        rows = cursor.fetchall()
        headers = [description[0] for description in cursor.description]
        sections.extend(["", f"## {title}", "", "```sql", sql.strip() + ";", "```", "", markdown_table(headers, rows)])

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text("\n".join(sections) + "\n", encoding="utf-8")
    print(f"Validação concluída: {len(matches)} consultas executadas.")
    print(f"Resultados salvos em: {OUTPUT.relative_to(ROOT)}")
    connection.close()


if __name__ == "__main__":
    main()
