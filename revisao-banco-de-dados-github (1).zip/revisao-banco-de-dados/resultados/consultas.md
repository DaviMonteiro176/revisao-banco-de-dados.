# Resultados das consultas

Gerados automaticamente por `scripts/validar_e_gerar_resultados.py` usando SQLite em memória.
Os dados são sintéticos. Execute o script novamente para reproduzir os resultados.

## Consulta 1: locações com cliente, veículo e categoria.

```sql
SELECT
    l.codigo AS locacao,
    c.nome_completo AS cliente,
    v.placa,
    v.modelo,
    cv.nome_descritivo AS categoria,
    l.data_retirada,
    l.data_prevista_devolucao,
    l.valor_total
FROM locacao AS l
JOIN cliente AS c ON c.cpf = l.cpf_cliente
JOIN veiculo AS v ON v.placa = l.placa_veiculo
JOIN categoria_veiculo AS cv ON cv.codigo = v.codigo_categoria
ORDER BY l.codigo;
```

| locacao | cliente | placa | modelo | categoria | data_retirada | data_prevista_devolucao | valor_total |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Ana Exemplo | AAA1B23 | Yaris | Econômico | 2026-10-01 | 2026-10-03 | 240 |
| 2 | Bruno Teste | BRA2C34 | Renegade | SUV | 2026-10-05 | 2026-10-08 | 750 |
| 3 | Ana Exemplo | SUV3D45 | Onix | Econômico | 2026-09-10 | 2026-09-12 | 240 |
| 4 | Carla Fictícia | EXE4E56 | Corolla | Executivo | 2026-10-12 | 2026-10-15 | 960 |

## Consulta 2: quantidade de locações e valor total registrado por cliente, inclusive sem locações.

```sql
SELECT
    c.nome_completo AS cliente,
    COUNT(l.codigo) AS quantidade_locacoes,
    COALESCE(SUM(l.valor_total), 0) AS total_locado
FROM cliente AS c
LEFT JOIN locacao AS l ON l.cpf_cliente = c.cpf
GROUP BY c.cpf, c.nome_completo
ORDER BY c.nome_completo;
```

| cliente | quantidade_locacoes | total_locado |
| --- | --- | --- |
| Ana Exemplo | 2 | 480 |
| Bruno Teste | 1 | 750 |
| Carla Fictícia | 1 | 960 |
| Diego Simulado | 0 | 0 |

## Consulta 3: quantidade de veículos cadastrados em cada categoria.

```sql
SELECT
    cv.nome_descritivo AS categoria,
    COUNT(v.placa) AS quantidade_veiculos
FROM categoria_veiculo AS cv
LEFT JOIN veiculo AS v ON v.codigo_categoria = cv.codigo
GROUP BY cv.codigo, cv.nome_descritivo
ORDER BY cv.codigo;
```

| categoria | quantidade_veiculos |
| --- | --- |
| Econômico | 2 |
| SUV | 1 |
| Executivo | 1 |
