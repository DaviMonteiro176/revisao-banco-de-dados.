# Revisão de Banco de Dados — Locadora DriveMax

Projeto de estudo que responde à revisão de Banco de Dados do UniBH: etapas de modelagem, DER conceitual, esquema relacional, SQL DDL, dados fictícios, consultas e resultados.

## Conteúdo do repositório

```text
revisao-banco-de-dados/
├── README.md
├── docs/
│   └── respostas_revisao.md
├── der/
│   ├── DER_conceitual_locadora.png
│   └── DER_conceitual_locadora.dot
├── sql/
│   ├── 01_criar_tabelas.sql
│   ├── 02_dados_ficticios.sql
│   └── 03_consultas.sql
├── scripts/
│   └── validar_e_gerar_resultados.py
└── resultados/
    └── consultas.md
```

## Como estudar/entender o projeto

Leia `docs/respostas_revisao.md` junto com o enunciado. O DER é o modelo conceitual; o esquema relacional mostra a passagem para tabelas; e os arquivos SQL contêm a implementação e os testes com dados sintéticos.

## Como executar

### Opção A — executar a validação e gerar os resultados com Python

É necessário Python 3. O script usa apenas a biblioteca padrão `sqlite3` e executa os arquivos SQL em um banco SQLite temporário na memória:

```bash
python3 scripts/validar_e_gerar_resultados.py
```

O script verifica a criação das tabelas, carrega os dados fictícios, executa as consultas e atualiza `resultados/consultas.md` com as queries e as saídas obtidas.

### Opção B — executar em um SGBD/cliente SQL

Use um banco vazio no SQLite ou MySQL 8.0.16 ou superior e execute os arquivos nesta ordem:

1. `sql/01_criar_tabelas.sql`
2. `sql/02_dados_ficticios.sql`
3. `sql/03_consultas.sql`

O DDL usa tipos e restrições comuns a esses SGBDs. A execução automatizada incluída no repositório foi testada com SQLite; se a disciplina exigir um SGBD específico, confirme a compatibilidade com o professor.

## Decisões e hipóteses do exercício

- `valor_total` é apresentado como derivado no DER, pois o enunciado diz que é calculado. Na tabela, é guardado como valor calculado no momento da locação, para preservar o total histórico. Para o exemplo, considera-se diária multiplicada pelo número de dias entre retirada e devolução prevista. A política de cobrança real deve ser confirmada com o professor/cliente.
- `CPF` e placa são armazenados como texto para preservar zeros à esquerda e evitar operações aritméticas indevidas.
- Os CPFs e as CNHs do seed são identificadores deliberadamente fictícios, sem correspondência com pessoas reais. Não substitua esses dados por informações pessoais antes de publicar o repositório.
- O modelo não impede duas locações do mesmo veículo em períodos sobrepostos: essa regra não foi explicitada no enunciado e exigiria uma validação adicional.

## Publicar no GitHub

1. Entre em [github.com](https://github.com/) e crie um repositório novo, por exemplo `revisao-banco-de-dados`. Se os arquivos já estão nesta pasta, não marque a opção de criar outro README no site.
2. No terminal, entre na pasta do projeto e execute:

```bash
git init
git add .
git commit -m "Adiciona revisão de banco de dados"
git branch -M main
git remote add origin https://github.com/DaviMonteiro176/revisao-banco-de-dados.git
git push -u origin main
```

Quando solicitado, autentique-se pelo navegador ou use um token pessoal do GitHub como senha — nunca publique nem envie seu token em arquivos ou mensagens.

Se preferir não usar o terminal, crie o repositório no GitHub, selecione **Add file → Upload files**, arraste os arquivos desta pasta e confirme com **Commit changes**. Antes de enviar, revise se não há senhas, dados reais ou outros arquivos privados.
