-- Consulta 1: locações com cliente, veículo e categoria.
SELECT
    l.codigo AS locacao,
    c.nome_completo AS cliente,
    v.placa,
    v.modelo,
    cv.nome_descritivo AS categoria,
    l.data_retirada,
    l.data_prevista_devolucao,
    l.valor_total
FROM locacao AS l
JOIN cliente AS c ON c.cpf = l.cpf_cliente
JOIN veiculo AS v ON v.placa = l.placa_veiculo
JOIN categoria_veiculo AS cv ON cv.codigo = v.codigo_categoria
ORDER BY l.codigo;

-- Consulta 2: quantidade de locações e valor total registrado por cliente, inclusive sem locações.
SELECT
    c.nome_completo AS cliente,
    COUNT(l.codigo) AS quantidade_locacoes,
    COALESCE(SUM(l.valor_total), 0) AS total_locado
FROM cliente AS c
LEFT JOIN locacao AS l ON l.cpf_cliente = c.cpf
GROUP BY c.cpf, c.nome_completo
ORDER BY c.nome_completo;

-- Consulta 3: quantidade de veículos cadastrados em cada categoria.
SELECT
    cv.nome_descritivo AS categoria,
    COUNT(v.placa) AS quantidade_veiculos
FROM categoria_veiculo AS cv
LEFT JOIN veiculo AS v ON v.codigo_categoria = cv.codigo
GROUP BY cv.codigo, cv.nome_descritivo
ORDER BY cv.codigo;
