-- Dados integralmente fictícios para fins de teste.
-- Os CPFs abaixo são valores artificiais e não devem identificar pessoas reais.

INSERT INTO cliente (
    cpf, nome_completo, cnh_numero, cnh_categoria, telefone,
    endereco_logradouro, endereco_numero, endereco_bairro, endereco_cidade
) VALUES
('11111111111', 'Ana Exemplo', 'CNH-TESTE-001', 'B', '31990000001', 'Rua das Flores', '10', 'Centro', 'Vespasiano'),
('22222222222', 'Bruno Teste', 'CNH-TESTE-002', 'AB', '31990000002', 'Rua do Sol', '25', 'Jardim', 'Lagoa Santa'),
('33333333333', 'Carla Fictícia', 'CNH-TESTE-003', 'C', '31990000003', 'Av. Central', '300', 'Santa Clara', 'Pedro Leopoldo'),
('44444444444', 'Diego Simulado', 'CNH-TESTE-004', 'B', '31990000004', 'Rua Um', '4', 'Centro', 'Vespasiano');

INSERT INTO categoria_veiculo (codigo, nome_descritivo, valor_diaria) VALUES
(1, 'Econômico', 120.00),
(2, 'SUV', 250.00),
(3, 'Executivo', 320.00);

INSERT INTO veiculo (
    placa, modelo, marca, ano_fabricacao, cor, quilometragem_atual, codigo_categoria
) VALUES
('AAA1B23', 'Yaris', 'Toyota', 2022, 'Branco', 45200, 1),
('BRA2C34', 'Renegade', 'Jeep', 2021, 'Preto', 31000, 2),
('SUV3D45', 'Onix', 'Chevrolet', 2023, 'Cinza', 18000, 1),
('EXE4E56', 'Corolla', 'Toyota', 2024, 'Prata', 12000, 3);

-- Para estes exemplos, valor_total = valor_diaria × dias previstos.
INSERT INTO locacao (
    codigo, data_retirada, data_prevista_devolucao,
    quilometragem_retirada, valor_total, cpf_cliente, placa_veiculo
) VALUES
(1, '2026-10-01', '2026-10-03', 45200, 240.00, '11111111111', 'AAA1B23'),
(2, '2026-10-05', '2026-10-08', 31000, 750.00, '22222222222', 'BRA2C34'),
(3, '2026-09-10', '2026-09-12', 17700, 240.00, '11111111111', 'SUV3D45'),
(4, '2026-10-12', '2026-10-15', 12000, 960.00, '33333333333', 'EXE4E56');
