-- DDL da locadora DriveMax.
-- Compatível com SQLite e MySQL 8.0.16+ (CHECK constraints).
-- Execute em um banco vazio.

CREATE TABLE cliente (
    cpf CHAR(11) NOT NULL,
    nome_completo VARCHAR(120) NOT NULL,
    cnh_numero VARCHAR(20) NOT NULL,
    cnh_categoria VARCHAR(5) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    endereco_logradouro VARCHAR(120) NOT NULL,
    endereco_numero VARCHAR(15) NOT NULL,
    endereco_bairro VARCHAR(80) NOT NULL,
    endereco_cidade VARCHAR(80) NOT NULL,
    CONSTRAINT pk_cliente PRIMARY KEY (cpf),
    CONSTRAINT ck_cliente_cpf_tamanho CHECK (LENGTH(cpf) = 11)
);

CREATE TABLE categoria_veiculo (
    codigo INTEGER NOT NULL,
    nome_descritivo VARCHAR(60) NOT NULL,
    valor_diaria DECIMAL(10,2) NOT NULL,
    CONSTRAINT pk_categoria_veiculo PRIMARY KEY (codigo),
    CONSTRAINT ck_categoria_valor_diaria CHECK (valor_diaria > 0)
);

CREATE TABLE veiculo (
    placa CHAR(7) NOT NULL,
    modelo VARCHAR(80) NOT NULL,
    marca VARCHAR(60) NOT NULL,
    ano_fabricacao SMALLINT NOT NULL,
    cor VARCHAR(30) NOT NULL,
    quilometragem_atual INTEGER NOT NULL,
    codigo_categoria INTEGER NOT NULL,
    CONSTRAINT pk_veiculo PRIMARY KEY (placa),
    CONSTRAINT fk_veiculo_categoria FOREIGN KEY (codigo_categoria)
        REFERENCES categoria_veiculo (codigo),
    CONSTRAINT ck_veiculo_ano CHECK (ano_fabricacao BETWEEN 1900 AND 2100),
    CONSTRAINT ck_veiculo_km CHECK (quilometragem_atual >= 0)
);

CREATE TABLE locacao (
    codigo INTEGER NOT NULL,
    data_retirada DATE NOT NULL,
    data_prevista_devolucao DATE NOT NULL,
    quilometragem_retirada INTEGER NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    cpf_cliente CHAR(11) NOT NULL,
    placa_veiculo CHAR(7) NOT NULL,
    CONSTRAINT pk_locacao PRIMARY KEY (codigo),
    CONSTRAINT fk_locacao_cliente FOREIGN KEY (cpf_cliente)
        REFERENCES cliente (cpf),
    CONSTRAINT fk_locacao_veiculo FOREIGN KEY (placa_veiculo)
        REFERENCES veiculo (placa),
    CONSTRAINT ck_locacao_datas CHECK (data_prevista_devolucao >= data_retirada),
    CONSTRAINT ck_locacao_km CHECK (quilometragem_retirada >= 0),
    CONSTRAINT ck_locacao_valor CHECK (valor_total >= 0)
);
