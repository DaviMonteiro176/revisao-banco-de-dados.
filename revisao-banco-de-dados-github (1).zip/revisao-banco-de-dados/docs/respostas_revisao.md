# Respostas da revisão — Banco de Dados

## Parte I — Fundamentos da modelagem de dados

### Projeto conceitual

- **Objetivo:** descrever os dados importantes do domínio e como eles se relacionam, sem decidir como serão implementados em um SGBD.
- **Dependência do SGBD:** nenhuma ou muito baixa; é uma visão de negócio, independente da tecnologia.
- **Artefato:** modelo conceitual, normalmente apresentado como um Diagrama Entidade-Relacionamento (DER).

### Projeto lógico

- **Objetivo:** converter o modelo conceitual para uma estrutura lógica de dados. No modelo relacional, isso define tabelas, colunas, chaves primárias, chaves estrangeiras e regras de integridade.
- **Dependência do SGBD:** baixa; em geral, segue o modelo relacional e evita detalhes exclusivos de um produto. Pode depender do modelo de dados escolhido.
- **Artefato:** esquema relacional/lógico.

### Projeto físico

- **Objetivo:** especificar como a estrutura será criada no SGBD escolhido, incluindo tipos concretos, restrições e comandos de criação.
- **Dependência do SGBD:** alta; os tipos e alguns recursos/sintaxes variam entre MySQL, PostgreSQL, SQLite e outros.
- **Artefato:** script SQL DDL e banco implementado.

## Parte II — Estudo de caso DriveMax Rent a Car

### Etapa 1 — Modelo conceitual

O arquivo [DER conceitual em PNG](../der/DER_conceitual_locadora.png) mostra as entidades, atributos, relacionamentos e cardinalidades. O arquivo [DOT editável](../der/DER_conceitual_locadora.dot) é a fonte do desenho.

Entidades e identificadores:

- **CLIENTE:** CPF (identificador); nome completo; telefone; CNH composta por número e categoria; endereço composto por logradouro, número, bairro e cidade.
- **CATEGORIA DE VEÍCULO:** código (identificador); nome descritivo; valor da diária.
- **VEÍCULO:** placa (identificador); modelo; marca; ano de fabricação; cor; quilometragem atual.
- **LOCAÇÃO:** código (identificador); data de retirada; data prevista para devolução; quilometragem no momento da retirada; valor total.

Relacionamentos:

- **CLIENTE 1:N LOCAÇÃO:** um cliente pode realizar várias locações; cada locação pertence a um cliente.
- **VEÍCULO 1:N LOCAÇÃO:** um veículo pode aparecer em várias locações ao longo do tempo; cada locação referencia um veículo.
- **CATEGORIA DE VEÍCULO 1:N VEÍCULO:** uma categoria pode classificar vários veículos; cada veículo pertence a uma categoria.

Não há relacionamento M:N descrito no enunciado. O atributo `valor_total` foi marcado como derivado no DER porque o texto o descreve como calculado. A fórmula exata não está especificada; neste exemplo, considera-se a diária da categoria multiplicada pelos dias previstos de locação. A regra de cobrança deve ser confirmada com o professor.

### Etapa 2 — Modelo lógico/relacional

```text
CLIENTE(
  CPF PK,
  nome_completo,
  CNH_numero,
  CNH_categoria,
  telefone,
  endereco_logradouro,
  endereco_numero,
  endereco_bairro,
  endereco_cidade
)

CATEGORIA_VEICULO(
  codigo PK,
  nome_descritivo,
  valor_diaria
)

VEICULO(
  placa PK,
  modelo,
  marca,
  ano_fabricacao,
  cor,
  quilometragem_atual,
  codigo_categoria FK → CATEGORIA_VEICULO.codigo
)

LOCACAO(
  codigo PK,
  data_retirada,
  data_prevista_devolucao,
  quilometragem_retirada,
  valor_total,
  CPF_cliente FK → CLIENTE.CPF,
  placa_veiculo FK → VEICULO.placa
)
```

No relacionamento 1:N, a FK fica no lado N: `VEICULO` guarda a categoria a que pertence; `LOCACAO` guarda o cliente e o veículo envolvidos. O endereço e a CNH, que são compostos no modelo conceitual, foram desmembrados em colunas atômicas no relacional.

### Etapa 3 — Modelo físico / SQL DDL

O script completo está em [`sql/01_criar_tabelas.sql`](../sql/01_criar_tabelas.sql). Ele define as quatro tabelas, tipos de dados, PKs, FKs, `NOT NULL` e `CHECK`.

### Etapa 4 — Teste

- Os dados fictícios para popular as tabelas estão em [`sql/02_dados_ficticios.sql`](../sql/02_dados_ficticios.sql).
- As consultas estão em [`sql/03_consultas.sql`](../sql/03_consultas.sql).
- O resultado das consultas está em [`resultados/consultas.md`](../resultados/consultas.md).
- Para repetir a execução e atualizar os resultados, execute `python3 scripts/validar_e_gerar_resultados.py` na raiz do repositório.

Os dados são sintéticos e não devem ser substituídos por CPFs, CNHs, telefones ou endereços reais em um repositório público.
